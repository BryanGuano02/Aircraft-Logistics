﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ALV._06
{
    public partial class Form2 : Form
    {
        /*=========================================================================================
         ESTRUCTURAS
        ==========================================================================================*/
        public struct Pasajero
        {
            public string nombre;
            public string apellido;
            public string claseV;
        }

        public struct Destinos
        {
            public string destinos;
            public string horas;
            public string tiempoV;
            public int items;
        }

        public struct Boletos
        {
            public string ciudad;
            public string cClase;
            public int numero1 = 0;
            public int numero2 = 0;
            public int numero3 = 0;
            public int numero4 = 0;
            public int numero5 = 0;
            public int codigo;
        }

        public struct Precios
        {
            public double subtotal;
            public double costoAsiento;
            public double impuestoIVA;
            public double total;
        }


        /*=====================================================================================
         * METODOS
         * ==================================================================================*/

        public void validarNombre()
        {
            if (nombreTxt.Text.Trim() != string.Empty && nombreTxt.Text.All(Char.IsLetter))
            {
                if (apellidoTxt.Text.Trim() != string.Empty && apellidoTxt.Text.All(Char.IsLetter))
                {
                    btnComprar.Enabled = true;
                }
                errorProvider1.SetError(nombreTxt, "");
            }
            else
            {
                if (!(nombreTxt.Text.All(Char.IsLetter)))
                {
                    errorProvider1.SetError(nombreTxt, "Debe ingresar letras en este campo");
                }
                else
                {
                    errorProvider1.SetError(nombreTxt, "Debe completar todos los campos");
                }
                btnComprar.Enabled = false;
                nombreTxt.Focus();
            }
        }

        public void validarApellido()
        {
            if (apellidoTxt.Text.Trim() != string.Empty && apellidoTxt.Text.All(Char.IsLetter))
            {
                if (nombreTxt.Text.Trim() != string.Empty && nombreTxt.Text.All(Char.IsLetter))
                {
                    btnComprar.Enabled = true;
                }
                errorProvider1.SetError(apellidoTxt, "");
            }
            else
            {
                if (!(apellidoTxt.Text.All(Char.IsLetter)))
                {
                    errorProvider1.SetError(apellidoTxt, "Debe ingresar letras en este campo");
                }
                else
                {
                    errorProvider1.SetError(apellidoTxt, "Debe completar todos los campos");
                }
                btnComprar.Enabled = false;
                apellidoTxt.Focus();
            }

        }

        public void limpiarAccion()
        {
            nombreTxt.Text = null;
            apellidoTxt.Text = null;
            cmbDestinos.SelectedItem = null;
            cmbHorarios.SelectedItem = null;
            rdbtClaseE.Checked = false;
            rdbtPrimeraC.Checked = false;
        }

        /*=====================================================================================
         * BOTONES
         * ==================================================================================*/

        Pasajero pasajero;
        Destinos destinos;
        Boletos boleto;
        Precios precios;

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            btnComprar.Enabled = false;
        }

        private void nombreTxt_TextChanged(object sender, EventArgs e)
        {
            validarNombre();
            pasajero.nombre = nombreTxt.Text.ToUpper();
        }

        private void apellidoTxt_TextChanged(object sender, EventArgs e)
        {
            validarApellido();
            pasajero.apellido = apellidoTxt.Text.ToUpper();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            limpiarAccion();
        }

        private void cmbDestinos_SelectedIndexChanged(object sender, EventArgs e)
        {
            destinos.items = cmbDestinos.SelectedIndex;

            switch (destinos.items)
            {
                case 0:
                    destinos.destinos = "COLOMBIA-BOGOTÁ";
                    boleto.ciudad = "BO";
                    cmbHorarios.Items.Clear();
                    cmbHorarios.Items.Add("05:00 A.M.");
                    cmbHorarios.Items.Add("14:00 P.M.");
                    destinos.tiempoV = "01h40";
                    boleto.numero1++;
                    boleto.codigo=boleto.numero1;
                    precios.subtotal = 265.44;
                    break;

                case 1:
                    destinos.destinos = "ECUADOR-CUENCA";
                    boleto.ciudad = "CUE";
                    cmbHorarios.Items.Clear();
                    cmbHorarios.Items.Add("06:00 A.M.");
                    cmbHorarios.Items.Add("15:00 P.M.");
                    destinos.tiempoV = "01h00";
                    boleto.numero2++;
                    boleto.codigo = boleto.numero2;
                    precios.subtotal = 83.65;
                    break;

                case 2:
                    destinos.destinos = "ECUADOR-GUAYAQUIL";
                    boleto.ciudad = "GUA";
                    cmbHorarios.Items.Clear();
                    cmbHorarios.Items.Add("07:00 A.M.");
                    cmbHorarios.Items.Add("18:00 P.M.");
                    destinos.tiempoV = "01h00";
                    boleto.numero3++;
                    boleto.codigo = boleto.numero3;
                    precios.subtotal = 90.25;
                    break;

                case 3:
                    destinos.destinos = "PANAMÁ-PANAMÁ";
                    boleto.ciudad = "PAN";
                    cmbHorarios.Items.Clear();
                    cmbHorarios.Items.Add("08:00 A.M.");
                    cmbHorarios.Items.Add("19:00 P.M.");
                    destinos.tiempoV = "01h45";
                    boleto.numero4++;
                    boleto.codigo = boleto.numero4;
                    precios.subtotal = 202.50;
                    break;

                case 4:
                    destinos.destinos = "PERÚ-LIMA";
                    boleto.ciudad = "LIM";
                    cmbHorarios.Items.Clear();
                    cmbHorarios.Items.Add("09:00 A.M.");
                    cmbHorarios.Items.Add("22:00 P.M.");
                    destinos.tiempoV = "02h15";
                    boleto.numero5++;
                    boleto.codigo = boleto.numero5;
                    precios.subtotal = 240.00;
                    break;
            }
        }

        private void rdbtPrimeraC_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtPrimeraC.Checked == true)
            {
                pasajero.claseV = "PRIMERA CLASE";
                boleto.cClase = "PC";
                precios.costoAsiento = 65.00;
            }
        }

        private void rdbtClaseE_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtClaseE.Checked == true)
            {
                pasajero.claseV = "CLASE ECONÓMICA";
                boleto.cClase = "EC";
                precios.costoAsiento = 0.00;
            }
        }

        private void btnComprar_Click(object sender, EventArgs e)
        {
            lblNombreP.Text = pasajero.apellido + "  " + pasajero.nombre;
            claseLbl.Text = pasajero.claseV;
            lblTiempo.Text = destinos.tiempoV;
            destinosLbl.Text = destinos.destinos;
            lblCodigo.Text = boleto.ciudad + boleto.cClase+boleto.codigo;
            asientoLbl.Text = boleto.cClase+boleto.codigo;
            precios.subtotal = precios.subtotal + precios.costoAsiento;
            precios.impuestoIVA = precios.subtotal * 0.12;
            precios.total = precios.subtotal + precios.impuestoIVA;

            Form3 recibo=new Form3(precios);
            recibo.ShowDialog();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
