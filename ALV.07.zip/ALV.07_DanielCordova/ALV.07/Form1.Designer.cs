﻿namespace ALV._06
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblBienvenida = new System.Windows.Forms.Label();
            this.gboxIntrucciones = new System.Windows.Forms.GroupBox();
            this.chkConfirmación = new System.Windows.Forms.CheckBox();
            this.btnContinuar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblBienvenida
            // 
            this.lblBienvenida.AutoSize = true;
            this.lblBienvenida.BackColor = System.Drawing.Color.Transparent;
            this.lblBienvenida.Font = new System.Drawing.Font("Book Antiqua", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblBienvenida.ForeColor = System.Drawing.Color.White;
            this.lblBienvenida.Location = new System.Drawing.Point(324, 23);
            this.lblBienvenida.Name = "lblBienvenida";
            this.lblBienvenida.Size = new System.Drawing.Size(145, 22);
            this.lblBienvenida.TabIndex = 0;
            this.lblBienvenida.Text = "BIENVENIDO A:";
            // 
            // gboxIntrucciones
            // 
            this.gboxIntrucciones.BackColor = System.Drawing.Color.Transparent;
            this.gboxIntrucciones.Location = new System.Drawing.Point(244, 204);
            this.gboxIntrucciones.Name = "gboxIntrucciones";
            this.gboxIntrucciones.Size = new System.Drawing.Size(295, 152);
            this.gboxIntrucciones.TabIndex = 1;
            this.gboxIntrucciones.TabStop = false;
            this.gboxIntrucciones.Text = resources.GetString("gboxIntrucciones.Text");
            // 
            // chkConfirmación
            // 
            this.chkConfirmación.AutoSize = true;
            this.chkConfirmación.BackColor = System.Drawing.Color.Transparent;
            this.chkConfirmación.Location = new System.Drawing.Point(244, 362);
            this.chkConfirmación.Name = "chkConfirmación";
            this.chkConfirmación.Size = new System.Drawing.Size(252, 24);
            this.chkConfirmación.TabIndex = 2;
            this.chkConfirmación.Text = "\"He leído todas las instrucciones\"";
            this.chkConfirmación.UseVisualStyleBackColor = false;
            this.chkConfirmación.CheckedChanged += new System.EventHandler(this.chkConfirmación_CheckedChanged);
            // 
            // btnContinuar
            // 
            this.btnContinuar.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnContinuar.Location = new System.Drawing.Point(460, 409);
            this.btnContinuar.Name = "btnContinuar";
            this.btnContinuar.Size = new System.Drawing.Size(112, 29);
            this.btnContinuar.TabIndex = 3;
            this.btnContinuar.Text = "Continuar";
            this.btnContinuar.UseVisualStyleBackColor = true;
            this.btnContinuar.Click += new System.EventHandler(this.btnContinuar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(600, 450);
            this.Controls.Add(this.btnContinuar);
            this.Controls.Add(this.chkConfirmación);
            this.Controls.Add(this.gboxIntrucciones);
            this.Controls.Add(this.lblBienvenida);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MdiChildrenMinimizedAnchorBottom = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aircraft Logistics";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblBienvenida;
        private GroupBox gboxIntrucciones;
        private CheckBox chkConfirmación;
        private Button btnContinuar;
    }
}