﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ALV._06
{
    public partial class Form3 : Form
    {
        public Form3(Form2.Precios precios)
        {
            InitializeComponent();
            precios.subtotal = Math.Round(precios.subtotal, 2);
            lblSubtotal.Text = Convert.ToString(precios.subtotal);
            precios.total = Math.Round(precios.total, 2);
            lblTotal.Text = Convert.ToString(precios.total);
        }

        private void lblNombre_Click(object sender, EventArgs e)
        {
       
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
