namespace ALV._06
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnContinuar.Enabled = false;
        }
        private void chkConfirmaci�n_CheckedChanged(object sender, EventArgs e)
        {
            if (chkConfirmaci�n.Checked == true)
            {
                btnContinuar.Enabled = true;
            }
        }

        private void btnContinuar_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form = new Form2();
            form.Show();
        }
    }
}