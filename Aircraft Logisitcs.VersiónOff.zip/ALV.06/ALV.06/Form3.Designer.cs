﻿namespace ALV._06
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.grpBoxRecibo = new System.Windows.Forms.GroupBox();
            this.lblIVA = new System.Windows.Forms.Label();
            this.costoLbl = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblSubtotal = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.rdbtEfectivo = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbtDebito = new System.Windows.Forms.RadioButton();
            this.grpBoxRecibo.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpBoxRecibo
            // 
            this.grpBoxRecibo.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.grpBoxRecibo.Controls.Add(this.lblIVA);
            this.grpBoxRecibo.Controls.Add(this.costoLbl);
            this.grpBoxRecibo.Controls.Add(this.label3);
            this.grpBoxRecibo.Controls.Add(this.label1);
            this.grpBoxRecibo.Controls.Add(this.lblTotal);
            this.grpBoxRecibo.Controls.Add(this.lblSubtotal);
            this.grpBoxRecibo.Controls.Add(this.label4);
            this.grpBoxRecibo.Controls.Add(this.label2);
            this.grpBoxRecibo.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.grpBoxRecibo.Location = new System.Drawing.Point(155, 141);
            this.grpBoxRecibo.Name = "grpBoxRecibo";
            this.grpBoxRecibo.Size = new System.Drawing.Size(394, 133);
            this.grpBoxRecibo.TabIndex = 0;
            this.grpBoxRecibo.TabStop = false;
            this.grpBoxRecibo.Text = "Recibo";
            // 
            // lblIVA
            // 
            this.lblIVA.AutoSize = true;
            this.lblIVA.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblIVA.Location = new System.Drawing.Point(202, 49);
            this.lblIVA.Name = "lblIVA";
            this.lblIVA.Size = new System.Drawing.Size(36, 23);
            this.lblIVA.TabIndex = 10;
            this.lblIVA.Text = "IVA";
            // 
            // costoLbl
            // 
            this.costoLbl.AutoSize = true;
            this.costoLbl.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.costoLbl.Location = new System.Drawing.Point(202, 72);
            this.costoLbl.Name = "costoLbl";
            this.costoLbl.Size = new System.Drawing.Size(64, 23);
            this.costoLbl.TabIndex = 9;
            this.costoLbl.Text = "COSTO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 23);
            this.label3.TabIndex = 8;
            this.label3.Text = "Costo asiento:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(126, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 23);
            this.label1.TabIndex = 7;
            this.label1.Text = "IVA:";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTotal.Location = new System.Drawing.Point(202, 96);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(57, 23);
            this.lblTotal.TabIndex = 6;
            this.lblTotal.Text = "TOTAL";
            // 
            // lblSubtotal
            // 
            this.lblSubtotal.AutoSize = true;
            this.lblSubtotal.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSubtotal.Location = new System.Drawing.Point(202, 26);
            this.lblSubtotal.Name = "lblSubtotal";
            this.lblSubtotal.Size = new System.Drawing.Size(87, 23);
            this.lblSubtotal.TabIndex = 5;
            this.lblSubtotal.Text = "SUBTOTAL";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(114, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 23);
            this.label4.TabIndex = 3;
            this.label4.Text = "Total:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Subtotal:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(441, 413);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 29);
            this.button1.TabIndex = 1;
            this.button1.Text = "Cerrar ventana";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rdbtEfectivo
            // 
            this.rdbtEfectivo.AutoSize = true;
            this.rdbtEfectivo.BackColor = System.Drawing.Color.Transparent;
            this.rdbtEfectivo.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rdbtEfectivo.Location = new System.Drawing.Point(6, 29);
            this.rdbtEfectivo.Name = "rdbtEfectivo";
            this.rdbtEfectivo.Size = new System.Drawing.Size(162, 27);
            this.rdbtEfectivo.TabIndex = 2;
            this.rdbtEfectivo.TabStop = true;
            this.rdbtEfectivo.Text = " Pago en efectivo";
            this.rdbtEfectivo.UseVisualStyleBackColor = false;
            this.rdbtEfectivo.CheckedChanged += new System.EventHandler(this.rdbtEfectivo_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.rdbtDebito);
            this.groupBox1.Controls.Add(this.rdbtEfectivo);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(130, 293);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(435, 80);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Formas de pago:";
            // 
            // rdbtDebito
            // 
            this.rdbtDebito.AutoSize = true;
            this.rdbtDebito.BackColor = System.Drawing.Color.Transparent;
            this.rdbtDebito.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rdbtDebito.Location = new System.Drawing.Point(190, 29);
            this.rdbtDebito.Name = "rdbtDebito";
            this.rdbtDebito.Size = new System.Drawing.Size(239, 27);
            this.rdbtDebito.TabIndex = 3;
            this.rdbtDebito.TabStop = true;
            this.rdbtDebito.Text = " Pago con tarjeta de débito";
            this.rdbtDebito.UseVisualStyleBackColor = false;
            this.rdbtDebito.CheckedChanged += new System.EventHandler(this.rdbtDebito_CheckedChanged);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(644, 454);
            this.ControlBox = false;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.grpBoxRecibo);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MdiChildrenMinimizedAnchorBottom = false;
            this.MinimizeBox = false;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aircraft Logistics";
            this.grpBoxRecibo.ResumeLayout(false);
            this.grpBoxRecibo.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox grpBoxRecibo;
        private Label lblTotal;
        private Label lblSubtotal;
        private Label label4;
        private Label label2;
        private Button button1;
        private Label lblIVA;
        private Label costoLbl;
        private Label label3;
        private Label label1;
        private RadioButton rdbtEfectivo;
        private GroupBox groupBox1;
        private RadioButton rdbtDebito;
    }
}