﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ALV._06
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            btnAceptar.Enabled = false;
        }

        private void numeroCItxt_TextChanged(object sender, EventArgs e)
        {
            if (numeroCItxt.Text.Trim() != string.Empty && numeroCItxt.Text.All(Char.IsDigit))
            {
                if (debitoTxt.Text.Trim() != string.Empty && debitoTxt.Text.All(Char.IsDigit))
                {
                    btnAceptar.Enabled = true;
                }
                errorProvider2.SetError(numeroCItxt, "");
            }
            else
            {
                if (!(numeroCItxt.Text.All(Char.IsDigit)))
                {
                    errorProvider2.SetError(numeroCItxt, "Debe ingresar números en este campo");
                }
                else
                {
                    errorProvider2.SetError(numeroCItxt, "Debe completar todos los campos");
                }
                btnAceptar.Enabled = false;
                numeroCItxt.Focus();
            }

        }


        private void debitoTxt_TextChanged_1(object sender, EventArgs e)
        {
            if (debitoTxt.Text.Trim() != string.Empty && debitoTxt.Text.All(Char.IsDigit))
            {
                if (numeroCItxt.Text.Trim() != string.Empty && numeroCItxt.Text.All(Char.IsDigit))
                {
                    btnAceptar.Enabled = true;
                }
                errorProvider2.SetError(numeroCItxt, "");
            }
            else
            {
                if (!(debitoTxt.Text.All(Char.IsDigit)))
                {
                    errorProvider2.SetError(debitoTxt, "Debe ingresar números en este campo");
                }
                else
                {
                    errorProvider2.SetError(debitoTxt, "Debe completar todos los campos");
                }
                btnAceptar.Enabled = false;
                debitoTxt.Focus();
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            this.Hide();
            DialogResult dialog = MessageBox.Show("Gracias por su compra ");
            if (dialog == DialogResult.OK)
            {
                this.Close();
            }
        }
    }
}
