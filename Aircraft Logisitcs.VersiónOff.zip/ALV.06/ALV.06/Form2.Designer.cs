﻿namespace ALV._06
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.gboxVariables = new System.Windows.Forms.GroupBox();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnComprar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbtClaseE = new System.Windows.Forms.RadioButton();
            this.rdbtPrimeraC = new System.Windows.Forms.RadioButton();
            this.cmbHorarios = new System.Windows.Forms.ComboBox();
            this.cmbDestinos = new System.Windows.Forms.ComboBox();
            this.apellidoTxt = new System.Windows.Forms.TextBox();
            this.nombreTxt = new System.Windows.Forms.TextBox();
            this.lblHorarios = new System.Windows.Forms.Label();
            this.lblDestinos = new System.Windows.Forms.Label();
            this.lblApellido = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblCodigo = new System.Windows.Forms.Label();
            this.asientoLbl = new System.Windows.Forms.Label();
            this.lblAsiento = new System.Windows.Forms.Label();
            this.lblTiempo = new System.Windows.Forms.Label();
            this.claseLbl = new System.Windows.Forms.Label();
            this.destinosLbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblNombreP = new System.Windows.Forms.Label();
            this.lblTiempoV = new System.Windows.Forms.Label();
            this.lblClaseV = new System.Windows.Forms.Label();
            this.lblDestino = new System.Windows.Forms.Label();
            this.lblOrigen = new System.Windows.Forms.Label();
            this.lblPasajero = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnSalir = new System.Windows.Forms.Button();
            this.gboxVariables.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // gboxVariables
            // 
            this.gboxVariables.BackColor = System.Drawing.Color.Transparent;
            this.gboxVariables.Controls.Add(this.btnLimpiar);
            this.gboxVariables.Controls.Add(this.btnComprar);
            this.gboxVariables.Controls.Add(this.groupBox1);
            this.gboxVariables.Controls.Add(this.cmbHorarios);
            this.gboxVariables.Controls.Add(this.cmbDestinos);
            this.gboxVariables.Controls.Add(this.apellidoTxt);
            this.gboxVariables.Controls.Add(this.nombreTxt);
            this.gboxVariables.Controls.Add(this.lblHorarios);
            this.gboxVariables.Controls.Add(this.lblDestinos);
            this.gboxVariables.Controls.Add(this.lblApellido);
            this.gboxVariables.Controls.Add(this.lblNombre);
            this.gboxVariables.Location = new System.Drawing.Point(95, 161);
            this.gboxVariables.Name = "gboxVariables";
            this.gboxVariables.Size = new System.Drawing.Size(950, 289);
            this.gboxVariables.TabIndex = 0;
            this.gboxVariables.TabStop = false;
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnLimpiar.Location = new System.Drawing.Point(465, 227);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(171, 32);
            this.btnLimpiar.TabIndex = 9;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnComprar
            // 
            this.btnComprar.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnComprar.Location = new System.Drawing.Point(229, 227);
            this.btnComprar.Name = "btnComprar";
            this.btnComprar.Size = new System.Drawing.Size(171, 32);
            this.btnComprar.TabIndex = 8;
            this.btnComprar.Text = "Comprar";
            this.btnComprar.UseVisualStyleBackColor = true;
            this.btnComprar.Click += new System.EventHandler(this.btnComprar_Click);
            this.btnComprar.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnComprar_MouseClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbtClaseE);
            this.groupBox1.Controls.Add(this.rdbtPrimeraC);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(22, 113);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(373, 95);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Clases:";
            // 
            // rdbtClaseE
            // 
            this.rdbtClaseE.AutoSize = true;
            this.rdbtClaseE.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rdbtClaseE.Location = new System.Drawing.Point(207, 44);
            this.rdbtClaseE.Name = "rdbtClaseE";
            this.rdbtClaseE.Size = new System.Drawing.Size(159, 27);
            this.rdbtClaseE.TabIndex = 1;
            this.rdbtClaseE.TabStop = true;
            this.rdbtClaseE.Text = "Clase Económica";
            this.rdbtClaseE.UseVisualStyleBackColor = true;
            this.rdbtClaseE.CheckedChanged += new System.EventHandler(this.rdbtClaseE_CheckedChanged);
            // 
            // rdbtPrimeraC
            // 
            this.rdbtPrimeraC.AutoSize = true;
            this.rdbtPrimeraC.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rdbtPrimeraC.Location = new System.Drawing.Point(24, 44);
            this.rdbtPrimeraC.Name = "rdbtPrimeraC";
            this.rdbtPrimeraC.Size = new System.Drawing.Size(135, 27);
            this.rdbtPrimeraC.TabIndex = 0;
            this.rdbtPrimeraC.TabStop = true;
            this.rdbtPrimeraC.Text = "Primera Clase";
            this.rdbtPrimeraC.UseVisualStyleBackColor = true;
            this.rdbtPrimeraC.CheckedChanged += new System.EventHandler(this.rdbtPrimeraC_CheckedChanged);
            // 
            // cmbHorarios
            // 
            this.cmbHorarios.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbHorarios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbHorarios.FormattingEnabled = true;
            this.cmbHorarios.Location = new System.Drawing.Point(643, 67);
            this.cmbHorarios.Name = "cmbHorarios";
            this.cmbHorarios.Size = new System.Drawing.Size(276, 28);
            this.cmbHorarios.TabIndex = 6;
            // 
            // cmbDestinos
            // 
            this.cmbDestinos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDestinos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDestinos.FormattingEnabled = true;
            this.cmbDestinos.Items.AddRange(new object[] {
            "COLOMBIA-BOGOTÁ",
            "ECUADOR-CUENCA",
            "ECUADOR-GUAYAQUIL",
            "PANAMÁ-PANAMÁ",
            "PERÚ-LIMA"});
            this.cmbDestinos.Location = new System.Drawing.Point(643, 23);
            this.cmbDestinos.Name = "cmbDestinos";
            this.cmbDestinos.Size = new System.Drawing.Size(276, 28);
            this.cmbDestinos.TabIndex = 5;
            this.cmbDestinos.SelectedIndexChanged += new System.EventHandler(this.cmbDestinos_SelectedIndexChanged);
            // 
            // apellidoTxt
            // 
            this.apellidoTxt.Location = new System.Drawing.Point(142, 68);
            this.apellidoTxt.Name = "apellidoTxt";
            this.apellidoTxt.Size = new System.Drawing.Size(253, 27);
            this.apellidoTxt.TabIndex = 4;
            this.apellidoTxt.TextChanged += new System.EventHandler(this.apellidoTxt_TextChanged);
            // 
            // nombreTxt
            // 
            this.nombreTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.nombreTxt.Location = new System.Drawing.Point(142, 23);
            this.nombreTxt.Name = "nombreTxt";
            this.nombreTxt.Size = new System.Drawing.Size(253, 27);
            this.nombreTxt.TabIndex = 4;
            this.nombreTxt.TextChanged += new System.EventHandler(this.nombreTxt_TextChanged);
            // 
            // lblHorarios
            // 
            this.lblHorarios.AutoSize = true;
            this.lblHorarios.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblHorarios.Location = new System.Drawing.Point(437, 68);
            this.lblHorarios.Name = "lblHorarios";
            this.lblHorarios.Size = new System.Drawing.Size(181, 23);
            this.lblHorarios.TabIndex = 3;
            this.lblHorarios.Text = "Horarios Disponibles:";
            // 
            // lblDestinos
            // 
            this.lblDestinos.AutoSize = true;
            this.lblDestinos.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDestinos.Location = new System.Drawing.Point(437, 23);
            this.lblDestinos.Name = "lblDestinos";
            this.lblDestinos.Size = new System.Drawing.Size(201, 23);
            this.lblDestinos.TabIndex = 2;
            this.lblDestinos.Text = "País-Ciudad de Destino:";
            // 
            // lblApellido
            // 
            this.lblApellido.AutoSize = true;
            this.lblApellido.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblApellido.Location = new System.Drawing.Point(22, 69);
            this.lblApellido.Name = "lblApellido";
            this.lblApellido.Size = new System.Drawing.Size(83, 23);
            this.lblApellido.TabIndex = 1;
            this.lblApellido.Text = "Apellido:";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNombre.Location = new System.Drawing.Point(22, 23);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(81, 23);
            this.lblNombre.TabIndex = 0;
            this.lblNombre.Text = "Nombre:";
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox2.BackgroundImage")));
            this.groupBox2.Controls.Add(this.lblCodigo);
            this.groupBox2.Controls.Add(this.asientoLbl);
            this.groupBox2.Controls.Add(this.lblAsiento);
            this.groupBox2.Controls.Add(this.lblTiempo);
            this.groupBox2.Controls.Add(this.claseLbl);
            this.groupBox2.Controls.Add(this.destinosLbl);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.lblNombreP);
            this.groupBox2.Controls.Add(this.lblTiempoV);
            this.groupBox2.Controls.Add(this.lblClaseV);
            this.groupBox2.Controls.Add(this.lblDestino);
            this.groupBox2.Controls.Add(this.lblOrigen);
            this.groupBox2.Controls.Add(this.lblPasajero);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(117, 511);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(904, 199);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Boleto";
            // 
            // lblCodigo
            // 
            this.lblCodigo.AutoSize = true;
            this.lblCodigo.BackColor = System.Drawing.Color.Transparent;
            this.lblCodigo.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblCodigo.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.lblCodigo.Location = new System.Drawing.Point(826, 9);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(76, 23);
            this.lblCodigo.TabIndex = 14;
            this.lblCodigo.Text = "CODIGO";
            // 
            // asientoLbl
            // 
            this.asientoLbl.AutoSize = true;
            this.asientoLbl.BackColor = System.Drawing.Color.Transparent;
            this.asientoLbl.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.asientoLbl.Location = new System.Drawing.Point(624, 61);
            this.asientoLbl.Name = "asientoLbl";
            this.asientoLbl.Size = new System.Drawing.Size(78, 23);
            this.asientoLbl.TabIndex = 13;
            this.asientoLbl.Text = "ASIENTO";
            // 
            // lblAsiento
            // 
            this.lblAsiento.AutoSize = true;
            this.lblAsiento.BackColor = System.Drawing.Color.White;
            this.lblAsiento.ForeColor = System.Drawing.Color.Black;
            this.lblAsiento.Location = new System.Drawing.Point(624, 39);
            this.lblAsiento.Name = "lblAsiento";
            this.lblAsiento.Size = new System.Drawing.Size(75, 23);
            this.lblAsiento.TabIndex = 12;
            this.lblAsiento.Text = "Asiento:";
            // 
            // lblTiempo
            // 
            this.lblTiempo.AutoSize = true;
            this.lblTiempo.BackColor = System.Drawing.Color.Transparent;
            this.lblTiempo.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTiempo.Location = new System.Drawing.Point(399, 136);
            this.lblTiempo.Name = "lblTiempo";
            this.lblTiempo.Size = new System.Drawing.Size(71, 23);
            this.lblTiempo.TabIndex = 10;
            this.lblTiempo.Text = "TIEMPO";
            // 
            // claseLbl
            // 
            this.claseLbl.AutoSize = true;
            this.claseLbl.BackColor = System.Drawing.Color.Transparent;
            this.claseLbl.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.claseLbl.Location = new System.Drawing.Point(399, 61);
            this.claseLbl.Name = "claseLbl";
            this.claseLbl.Size = new System.Drawing.Size(58, 23);
            this.claseLbl.TabIndex = 9;
            this.claseLbl.Text = "CLASE";
            // 
            // destinosLbl
            // 
            this.destinosLbl.AutoSize = true;
            this.destinosLbl.BackColor = System.Drawing.Color.Transparent;
            this.destinosLbl.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.destinosLbl.Location = new System.Drawing.Point(184, 136);
            this.destinosLbl.Name = "destinosLbl";
            this.destinosLbl.Size = new System.Drawing.Size(89, 23);
            this.destinosLbl.TabIndex = 8;
            this.destinosLbl.Text = "DESTINOS";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(22, 136);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 23);
            this.label1.TabIndex = 7;
            this.label1.Text = "ECUADOR-QUITO";
            // 
            // lblNombreP
            // 
            this.lblNombreP.AutoSize = true;
            this.lblNombreP.BackColor = System.Drawing.Color.Transparent;
            this.lblNombreP.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblNombreP.Location = new System.Drawing.Point(18, 61);
            this.lblNombreP.Name = "lblNombreP";
            this.lblNombreP.Size = new System.Drawing.Size(80, 23);
            this.lblNombreP.TabIndex = 6;
            this.lblNombreP.Text = "NOMBRE";
            // 
            // lblTiempoV
            // 
            this.lblTiempoV.AutoSize = true;
            this.lblTiempoV.BackColor = System.Drawing.Color.White;
            this.lblTiempoV.ForeColor = System.Drawing.Color.Black;
            this.lblTiempoV.Location = new System.Drawing.Point(399, 113);
            this.lblTiempoV.Name = "lblTiempoV";
            this.lblTiempoV.Size = new System.Drawing.Size(151, 23);
            this.lblTiempoV.TabIndex = 4;
            this.lblTiempoV.Text = "Tiempo de Vuelo:";
            // 
            // lblClaseV
            // 
            this.lblClaseV.AutoSize = true;
            this.lblClaseV.BackColor = System.Drawing.Color.White;
            this.lblClaseV.ForeColor = System.Drawing.Color.Black;
            this.lblClaseV.Location = new System.Drawing.Point(399, 39);
            this.lblClaseV.Name = "lblClaseV";
            this.lblClaseV.Size = new System.Drawing.Size(56, 23);
            this.lblClaseV.TabIndex = 3;
            this.lblClaseV.Text = "Clase:";
            // 
            // lblDestino
            // 
            this.lblDestino.AutoSize = true;
            this.lblDestino.BackColor = System.Drawing.Color.White;
            this.lblDestino.ForeColor = System.Drawing.Color.Black;
            this.lblDestino.Location = new System.Drawing.Point(184, 113);
            this.lblDestino.Name = "lblDestino";
            this.lblDestino.Size = new System.Drawing.Size(59, 23);
            this.lblDestino.TabIndex = 2;
            this.lblDestino.Text = "Hacia:";
            // 
            // lblOrigen
            // 
            this.lblOrigen.AutoSize = true;
            this.lblOrigen.BackColor = System.Drawing.Color.White;
            this.lblOrigen.ForeColor = System.Drawing.Color.Black;
            this.lblOrigen.Location = new System.Drawing.Point(22, 113);
            this.lblOrigen.Name = "lblOrigen";
            this.lblOrigen.Size = new System.Drawing.Size(64, 23);
            this.lblOrigen.TabIndex = 1;
            this.lblOrigen.Text = "Desde:";
            // 
            // lblPasajero
            // 
            this.lblPasajero.AutoSize = true;
            this.lblPasajero.BackColor = System.Drawing.Color.White;
            this.lblPasajero.ForeColor = System.Drawing.Color.Black;
            this.lblPasajero.Location = new System.Drawing.Point(18, 39);
            this.lblPasajero.Name = "lblPasajero";
            this.lblPasajero.Size = new System.Drawing.Size(81, 23);
            this.lblPasajero.TabIndex = 0;
            this.lblPasajero.Text = "Pasajero:";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSalir.Location = new System.Drawing.Point(930, 760);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(171, 32);
            this.btnSalir.TabIndex = 10;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1159, 827);
            this.ControlBox = false;
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.gboxVariables);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MdiChildrenMinimizedAnchorBottom = false;
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aircraft Logistics";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.gboxVariables.ResumeLayout(false);
            this.gboxVariables.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox gboxVariables;
        private ComboBox cmbHorarios;
        private ComboBox cmbDestinos;
        private TextBox apellidoTxt;
        private TextBox nombreTxt;
        private Label lblHorarios;
        private Label lblDestinos;
        private Label lblApellido;
        private Label lblNombre;
        private Button btnLimpiar;
        private Button btnComprar;
        private GroupBox groupBox1;
        private RadioButton rdbtClaseE;
        private RadioButton rdbtPrimeraC;
        private GroupBox groupBox2;
        private Label lblDestino;
        private Label lblOrigen;
        private Label lblPasajero;
        private Label lblTiempoV;
        private Label lblClaseV;
        private Label lblTiempo;
        private Label claseLbl;
        private Label destinosLbl;
        private Label label1;
        private Label lblNombreP;
        private ErrorProvider errorProvider1;
        private Label asientoLbl;
        private Label lblAsiento;
        private Label lblCodigo;
        private Button btnSalir;
    }
}