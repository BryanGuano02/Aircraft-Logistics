﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ALV._06
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            btnAceptar.Enabled = false;
        }

        private void numeroCItxt_TextChanged(object sender, EventArgs e)
        {
            if (txtNumeroCI.Text.Trim() != string.Empty && txtNumeroCI.Text.All(Char.IsDigit))
            {
                if (txtDebito.Text.Trim() != string.Empty && txtDebito.Text.All(Char.IsDigit))
                {
                    btnAceptar.Enabled = true;
                }
                errorProvider2.SetError(txtNumeroCI, "");
            }
            else
            {
                if (!(txtNumeroCI.Text.All(Char.IsDigit)))
                {
                    errorProvider2.SetError(txtNumeroCI, "Debe ingresar números en este campo");
                }
                else
                {
                    errorProvider2.SetError(txtNumeroCI, "Debe completar todos los campos");
                }
                btnAceptar.Enabled = false;
                txtNumeroCI.Focus();
            }

        }


        private void debitoTxt_TextChanged_1(object sender, EventArgs e)
        {
            if (txtDebito.Text.Trim() != string.Empty && txtDebito.Text.All(Char.IsDigit))
            {
                if (txtNumeroCI.Text.Trim() != string.Empty && txtNumeroCI.Text.All(Char.IsDigit))
                {
                    btnAceptar.Enabled = true;
                }
                errorProvider2.SetError(txtNumeroCI, "");
            }
            else
            {
                if (!(txtDebito.Text.All(Char.IsDigit)))
                {
                    errorProvider2.SetError(txtDebito, "Debe ingresar números en este campo");
                }
                else
                {
                    errorProvider2.SetError(txtDebito, "Debe completar todos los campos");
                }
                btnAceptar.Enabled = false;
                txtDebito.Focus();
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            this.Hide();
            DialogResult dialog = MessageBox.Show("Gracias por su compra ");
            if (dialog == DialogResult.OK)
            {
                this.Close();
            }
        }
    }
}
