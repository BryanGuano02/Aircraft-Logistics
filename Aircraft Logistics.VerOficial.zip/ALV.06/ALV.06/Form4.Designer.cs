﻿namespace ALV._06
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.lblNumeroCI = new System.Windows.Forms.Label();
            this.lblNumeroDebito = new System.Windows.Forms.Label();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.txtNumeroCI = new System.Windows.Forms.TextBox();
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.txtDebito = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNumeroCI
            // 
            this.lblNumeroCI.AutoSize = true;
            this.lblNumeroCI.BackColor = System.Drawing.Color.Transparent;
            this.lblNumeroCI.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNumeroCI.Location = new System.Drawing.Point(249, 211);
            this.lblNumeroCI.Name = "lblNumeroCI";
            this.lblNumeroCI.Size = new System.Drawing.Size(126, 23);
            this.lblNumeroCI.TabIndex = 0;
            this.lblNumeroCI.Text = "Número de CI:";
            // 
            // lblNumeroDebito
            // 
            this.lblNumeroDebito.AutoSize = true;
            this.lblNumeroDebito.BackColor = System.Drawing.Color.Transparent;
            this.lblNumeroDebito.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNumeroDebito.Location = new System.Drawing.Point(129, 251);
            this.lblNumeroDebito.Name = "lblNumeroDebito";
            this.lblNumeroDebito.Size = new System.Drawing.Size(246, 23);
            this.lblNumeroDebito.TabIndex = 1;
            this.lblNumeroDebito.Text = "Número de tarjeta de débito:";
            // 
            // btnAceptar
            // 
            this.btnAceptar.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAceptar.Location = new System.Drawing.Point(427, 324);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(198, 29);
            this.btnAceptar.TabIndex = 3;
            this.btnAceptar.Text = "Aceptar compra";
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // txtNumeroCI
            // 
            this.txtNumeroCI.Location = new System.Drawing.Point(411, 210);
            this.txtNumeroCI.Name = "txtNumeroCI";
            this.txtNumeroCI.Size = new System.Drawing.Size(380, 27);
            this.txtNumeroCI.TabIndex = 4;
            this.txtNumeroCI.TextChanged += new System.EventHandler(this.numeroCItxt_TextChanged);
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // txtDebito
            // 
            this.txtDebito.Location = new System.Drawing.Point(411, 247);
            this.txtDebito.Name = "txtDebito";
            this.txtDebito.Size = new System.Drawing.Size(380, 27);
            this.txtDebito.TabIndex = 5;
            this.txtDebito.TextChanged += new System.EventHandler(this.debitoTxt_TextChanged_1);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1039, 386);
            this.Controls.Add(this.txtDebito);
            this.Controls.Add(this.txtNumeroCI);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.lblNumeroDebito);
            this.Controls.Add(this.lblNumeroCI);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MdiChildrenMinimizedAnchorBottom = false;
            this.MinimizeBox = false;
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aircraft Logisitics";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblNumeroCI;
        private Label lblNumeroDebito;
        private Button btnAceptar;
        private TextBox txtNumeroCI;
        private ErrorProvider errorProvider2;
        private TextBox txtDebito;
    }
}