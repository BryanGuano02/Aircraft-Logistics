﻿namespace ALV._06
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.btgBoxRecibo = new System.Windows.Forms.GroupBox();
            this.lblIVA = new System.Windows.Forms.Label();
            this.lblCosto = new System.Windows.Forms.Label();
            this.lblAsientoExtra = new System.Windows.Forms.Label();
            this.lblImpuesto = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblSubtotal = new System.Windows.Forms.Label();
            this.lblTotalR = new System.Windows.Forms.Label();
            this.lblStotal = new System.Windows.Forms.Label();
            this.btnCerrarV = new System.Windows.Forms.Button();
            this.rbtEfectivo = new System.Windows.Forms.RadioButton();
            this.btgFormasDePago = new System.Windows.Forms.GroupBox();
            this.rbtDebito = new System.Windows.Forms.RadioButton();
            this.btgBoxRecibo.SuspendLayout();
            this.btgFormasDePago.SuspendLayout();
            this.SuspendLayout();
            // 
            // btgBoxRecibo
            // 
            this.btgBoxRecibo.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btgBoxRecibo.Controls.Add(this.lblIVA);
            this.btgBoxRecibo.Controls.Add(this.lblCosto);
            this.btgBoxRecibo.Controls.Add(this.lblAsientoExtra);
            this.btgBoxRecibo.Controls.Add(this.lblImpuesto);
            this.btgBoxRecibo.Controls.Add(this.lblTotal);
            this.btgBoxRecibo.Controls.Add(this.lblSubtotal);
            this.btgBoxRecibo.Controls.Add(this.lblTotalR);
            this.btgBoxRecibo.Controls.Add(this.lblStotal);
            this.btgBoxRecibo.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btgBoxRecibo.Location = new System.Drawing.Point(155, 141);
            this.btgBoxRecibo.Name = "btgBoxRecibo";
            this.btgBoxRecibo.Size = new System.Drawing.Size(394, 133);
            this.btgBoxRecibo.TabIndex = 0;
            this.btgBoxRecibo.TabStop = false;
            this.btgBoxRecibo.Text = "Recibo";
            // 
            // lblIVA
            // 
            this.lblIVA.AutoSize = true;
            this.lblIVA.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblIVA.Location = new System.Drawing.Point(202, 49);
            this.lblIVA.Name = "lblIVA";
            this.lblIVA.Size = new System.Drawing.Size(36, 23);
            this.lblIVA.TabIndex = 10;
            this.lblIVA.Text = "IVA";
            // 
            // lblCosto
            // 
            this.lblCosto.AutoSize = true;
            this.lblCosto.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblCosto.Location = new System.Drawing.Point(202, 72);
            this.lblCosto.Name = "lblCosto";
            this.lblCosto.Size = new System.Drawing.Size(64, 23);
            this.lblCosto.TabIndex = 9;
            this.lblCosto.Text = "COSTO";
            // 
            // lblAsientoExtra
            // 
            this.lblAsientoExtra.AutoSize = true;
            this.lblAsientoExtra.Location = new System.Drawing.Point(46, 73);
            this.lblAsientoExtra.Name = "lblAsientoExtra";
            this.lblAsientoExtra.Size = new System.Drawing.Size(122, 23);
            this.lblAsientoExtra.TabIndex = 8;
            this.lblAsientoExtra.Text = "Costo asiento:";
            // 
            // lblImpuesto
            // 
            this.lblImpuesto.AutoSize = true;
            this.lblImpuesto.Location = new System.Drawing.Point(126, 50);
            this.lblImpuesto.Name = "lblImpuesto";
            this.lblImpuesto.Size = new System.Drawing.Size(42, 23);
            this.lblImpuesto.TabIndex = 7;
            this.lblImpuesto.Text = "IVA:";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTotal.Location = new System.Drawing.Point(202, 96);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(57, 23);
            this.lblTotal.TabIndex = 6;
            this.lblTotal.Text = "TOTAL";
            // 
            // lblSubtotal
            // 
            this.lblSubtotal.AutoSize = true;
            this.lblSubtotal.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSubtotal.Location = new System.Drawing.Point(202, 26);
            this.lblSubtotal.Name = "lblSubtotal";
            this.lblSubtotal.Size = new System.Drawing.Size(87, 23);
            this.lblSubtotal.TabIndex = 5;
            this.lblSubtotal.Text = "SUBTOTAL";
            // 
            // lblTotalR
            // 
            this.lblTotalR.AutoSize = true;
            this.lblTotalR.Location = new System.Drawing.Point(114, 96);
            this.lblTotalR.Name = "lblTotalR";
            this.lblTotalR.Size = new System.Drawing.Size(54, 23);
            this.lblTotalR.TabIndex = 3;
            this.lblTotalR.Text = "Total:";
            // 
            // lblStotal
            // 
            this.lblStotal.AutoSize = true;
            this.lblStotal.Location = new System.Drawing.Point(84, 26);
            this.lblStotal.Name = "lblStotal";
            this.lblStotal.Size = new System.Drawing.Size(84, 23);
            this.lblStotal.TabIndex = 1;
            this.lblStotal.Text = "Subtotal:";
            this.lblStotal.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnCerrarV
            // 
            this.btnCerrarV.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCerrarV.Location = new System.Drawing.Point(441, 413);
            this.btnCerrarV.Name = "btnCerrarV";
            this.btnCerrarV.Size = new System.Drawing.Size(181, 29);
            this.btnCerrarV.TabIndex = 1;
            this.btnCerrarV.Text = "Cerrar ventana";
            this.btnCerrarV.UseVisualStyleBackColor = true;
            this.btnCerrarV.Click += new System.EventHandler(this.button1_Click);
            // 
            // rbtEfectivo
            // 
            this.rbtEfectivo.AutoSize = true;
            this.rbtEfectivo.BackColor = System.Drawing.Color.Transparent;
            this.rbtEfectivo.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbtEfectivo.Location = new System.Drawing.Point(6, 29);
            this.rbtEfectivo.Name = "rbtEfectivo";
            this.rbtEfectivo.Size = new System.Drawing.Size(162, 27);
            this.rbtEfectivo.TabIndex = 2;
            this.rbtEfectivo.TabStop = true;
            this.rbtEfectivo.Text = " Pago en efectivo";
            this.rbtEfectivo.UseVisualStyleBackColor = false;
            this.rbtEfectivo.CheckedChanged += new System.EventHandler(this.rdbtEfectivo_CheckedChanged);
            // 
            // btgFormasDePago
            // 
            this.btgFormasDePago.BackColor = System.Drawing.Color.Transparent;
            this.btgFormasDePago.Controls.Add(this.rbtDebito);
            this.btgFormasDePago.Controls.Add(this.rbtEfectivo);
            this.btgFormasDePago.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btgFormasDePago.Location = new System.Drawing.Point(130, 293);
            this.btgFormasDePago.Name = "btgFormasDePago";
            this.btgFormasDePago.Size = new System.Drawing.Size(435, 80);
            this.btgFormasDePago.TabIndex = 3;
            this.btgFormasDePago.TabStop = false;
            this.btgFormasDePago.Text = "Formas de pago:";
            // 
            // rbtDebito
            // 
            this.rbtDebito.AutoSize = true;
            this.rbtDebito.BackColor = System.Drawing.Color.Transparent;
            this.rbtDebito.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbtDebito.Location = new System.Drawing.Point(190, 29);
            this.rbtDebito.Name = "rbtDebito";
            this.rbtDebito.Size = new System.Drawing.Size(239, 27);
            this.rbtDebito.TabIndex = 3;
            this.rbtDebito.TabStop = true;
            this.rbtDebito.Text = " Pago con tarjeta de débito";
            this.rbtDebito.UseVisualStyleBackColor = false;
            this.rbtDebito.CheckedChanged += new System.EventHandler(this.rdbtDebito_CheckedChanged);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(644, 454);
            this.ControlBox = false;
            this.Controls.Add(this.btnCerrarV);
            this.Controls.Add(this.btgBoxRecibo);
            this.Controls.Add(this.btgFormasDePago);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MdiChildrenMinimizedAnchorBottom = false;
            this.MinimizeBox = false;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aircraft Logistics";
            this.btgBoxRecibo.ResumeLayout(false);
            this.btgBoxRecibo.PerformLayout();
            this.btgFormasDePago.ResumeLayout(false);
            this.btgFormasDePago.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox btgBoxRecibo;
        private Label lblTotal;
        private Label lblSubtotal;
        private Label lblTotalR;
        private Label lblStotal;
        private Button btnCerrarV;
        private Label lblIVA;
        private Label lblCosto;
        private Label lblAsientoExtra;
        private Label lblImpuesto;
        private RadioButton rbtEfectivo;
        private GroupBox btgFormasDePago;
        private RadioButton rbtDebito;
    }
}