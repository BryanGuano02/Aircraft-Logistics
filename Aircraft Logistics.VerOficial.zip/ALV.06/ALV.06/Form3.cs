﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ALV._06
{
    public partial class Form3 : Form
    {
        double total;
        public Form3(Form2.Precios precios)
        {
            InitializeComponent();
            lblSubtotal.Text = Convert.ToString(precios.subtotal);
            lblCosto.Text = Convert.ToString(precios.costoAsiento);
            precios.impuestoIVA = Math.Round(precios.impuestoIVA, 2);
            lblIVA.Text = Convert.ToString(precios.impuestoIVA);
            precios.total=precios.impuestoIVA+precios.subtotal+precios.costoAsiento;
            lblTotal.Text = Convert.ToString(precios.total);
            total=precios.total;
            
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void rdbtEfectivo_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtEfectivo.Checked == true)
            {
                Form5 form5 = new Form5();
                form5.Show();
            }
        }

        private void rdbtDebito_CheckedChanged(object sender, EventArgs e)
        {
            if(rbtDebito.Checked == true)
            {
                Form4 form4 = new Form4();
                form4.Show();

            }
        }
    }
}
