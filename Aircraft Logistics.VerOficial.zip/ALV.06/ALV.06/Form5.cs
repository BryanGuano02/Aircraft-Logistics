﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ALV._06
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            btnAceptar.Enabled = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if(txtDatos.Text.Trim() != string.Empty)
            {
               btnAceptar.Enabled = true;
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            this.Hide();
            DialogResult dialog = MessageBox.Show("Se le contactará inmediatamente por el contacto ingresado,para planificar un día de pago en la agencia ");
            if(dialog == DialogResult.OK)
            {
                this.Close();
            }

        }
    }
}
