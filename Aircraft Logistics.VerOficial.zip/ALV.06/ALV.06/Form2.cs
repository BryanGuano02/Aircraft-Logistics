﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ALV._06
{
    public partial class Form2 : Form
    {
        /*=========================================================================================
         ESTRUCTURAS
        ==========================================================================================*/
        public struct Pasajero
        {
            public string nombre;
            public string apellido;
            public string claseV;
        }

        public struct Destinos
        {
            public string destinos;
            public string horas;
            public string tiempoV;
            public int items;
        }

        public struct Boletos
        {
            public string ciudad;
            public string cClase;
            public int numero1 = 0;
            public int numero2 = 0;
            public int numero3 = 0;
            public int numero4 = 0;
            public int numero5 = 0;
            public int codigo;
        }

        public struct Precios
        {
            public double subtotal;
            public double costoAsiento;
            public double impuestoIVA;
            public double total;
        }


        /*=====================================================================================
         * METODOS
         * ==================================================================================*/

        public void validarNombre()
        {
            if (txtNombre.Text.Trim() != string.Empty && txtNombre.Text.All(Char.IsLetter))
            {
                if (txtApellido.Text.Trim() != string.Empty && txtApellido.Text.All(Char.IsLetter))
                {
                    btnComprar.Enabled = true;
                }
                errorProvider1.SetError(txtNombre, "");
            }
            else
            {
                if (!(txtNombre.Text.All(Char.IsLetter)))
                {
                    errorProvider1.SetError(txtNombre, "Debe ingresar letras en este campo");
                }
                else
                {
                    errorProvider1.SetError(txtNombre, "Debe completar todos los campos");
                }
                btnComprar.Enabled = false;
                txtNombre.Focus();
            }
        }

        public void validarApellido()
        {
            if (txtApellido.Text.Trim() != string.Empty && txtApellido.Text.All(Char.IsLetter))
            {
                if (txtNombre.Text.Trim() != string.Empty && txtNombre.Text.All(Char.IsLetter))
                {
                    btnComprar.Enabled = true;
                }
                errorProvider1.SetError(txtApellido, "");
            }
            else
            {
                if (!(txtApellido.Text.All(Char.IsLetter)))
                {
                    errorProvider1.SetError(txtApellido, "Debe ingresar letras en este campo");
                }
                else
                {
                    errorProvider1.SetError(txtApellido, "Debe completar todos los campos");
                }
                btnComprar.Enabled = false;
                txtApellido.Focus();
            }

        }

        public void limpiarAccion()
        {
            txtNombre.Text = null;
            txtApellido.Text = null;
            cmbDestinos.SelectedItem = null;
            cmbHorarios.SelectedItem = null;
            rbtClaseE.Checked = false;
            rbtPrimeraC.Checked = false;
        }

        /*=====================================================================================
         * BOTONES
         * ==================================================================================*/

        Pasajero pasajero;
        Destinos destinos;
        Boletos boleto;
        Precios precios;

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            btnComprar.Enabled = false;
        }

        private void nombreTxt_TextChanged(object sender, EventArgs e)
        {
            validarNombre();
            pasajero.nombre = txtNombre.Text.ToUpper();
        }

        private void apellidoTxt_TextChanged(object sender, EventArgs e)
        {
            validarApellido();
            pasajero.apellido = txtApellido.Text.ToUpper();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            limpiarAccion();
        }

        private void cmbDestinos_SelectedIndexChanged(object sender, EventArgs e)
        {
            destinos.items = cmbDestinos.SelectedIndex;

            switch (destinos.items)
            {
                case 0:
                    destinos.destinos = "COLOMBIA-BOGOTÁ";
                    boleto.ciudad = "BO";
                    cmbHorarios.Items.Clear();
                    cmbHorarios.Items.Add("14:00 P.M.");
                    destinos.tiempoV = "01h40";
                    boleto.numero1++;
                    boleto.codigo=boleto.numero1;
                    precios.subtotal = 265.44;
                    break;

                case 1:
                    destinos.destinos = "ECUADOR-CUENCA";
                    boleto.ciudad = "CUE";
                    cmbHorarios.Items.Clear();
                    cmbHorarios.Items.Add("06:00 A.M.");
                    destinos.tiempoV = "01h00";
                    boleto.numero2++;
                    boleto.codigo = boleto.numero2;
                    precios.subtotal = 83.65;
                    break;

                case 2:
                    destinos.destinos = "ECUADOR-GUAYAQUIL";
                    boleto.ciudad = "GUA";
                    cmbHorarios.Items.Clear();
                    cmbHorarios.Items.Add("07:00 A.M.");
                    destinos.tiempoV = "01h00";
                    boleto.numero3++;
                    boleto.codigo = boleto.numero3;
                    precios.subtotal = 90.25;
                    break;

                case 3:
                    destinos.destinos = "PANAMÁ-PANAMÁ";
                    boleto.ciudad = "PAN";
                    cmbHorarios.Items.Clear();
                    cmbHorarios.Items.Add("19:00 P.M.");
                    destinos.tiempoV = "01h45";
                    boleto.numero4++;
                    boleto.codigo = boleto.numero4;
                    precios.subtotal = 202.50;
                    break;

                case 4:
                    destinos.destinos = "PERÚ-LIMA";
                    boleto.ciudad = "LIM";
                    cmbHorarios.Items.Clear();
                    cmbHorarios.Items.Add("22:00 P.M.");
                    destinos.tiempoV = "02h15";
                    boleto.numero5++;
                    boleto.codigo = boleto.numero5;
                    precios.subtotal = 240.00;
                    break;
            }
        }

        private void rdbtPrimeraC_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtPrimeraC.Checked == true)
            {
                pasajero.claseV = "PRIMERA CLASE";
                boleto.cClase = "PC";
                precios.costoAsiento = 65.00;
            }
        }

        private void rdbtClaseE_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtClaseE.Checked == true)
            {
                pasajero.claseV = "CLASE ECONÓMICA";
                boleto.cClase = "EC";
                precios.costoAsiento = 0.00;
            }
        }

        int contadorCompras;
        private void btnComprar_MouseClick(object sender, MouseEventArgs e)
        {
            contadorCompras++;
        }
        private void btnComprar_Click(object sender, EventArgs e)
        {
            if (contadorCompras <= 2)
            {
                lblNombreP.Text = pasajero.apellido + "  " + pasajero.nombre;
                lblClase.Text = pasajero.claseV;
                lblTiempo.Text = destinos.tiempoV;
                lblDestinosV.Text = destinos.destinos;
                lblCodigo.Text = boleto.ciudad + boleto.cClase + boleto.codigo;
                lblAsientoV.Text = boleto.cClase + boleto.codigo;
                precios.impuestoIVA = precios.subtotal * 0.12;
                precios.total = precios.subtotal + precios.impuestoIVA;

                Form3 recibo = new Form3(precios);
                recibo.ShowDialog();
            }
            else
            {
                MessageBox.Show("Boletos Agotados. Intente de nuevo más tarde.");
                limpiarAccion();
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("El proceso de compra se cancelará. ¿Desea cerrar el programa?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dialog == DialogResult.Yes)
            {
                this.Close();
            }
            else if (dialog == DialogResult.No)
            {
                this.Activate();
            }
        }

        
    }
}
