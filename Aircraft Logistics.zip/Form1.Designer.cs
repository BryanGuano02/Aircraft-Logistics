﻿struct Pasajero
{
    string nombres;
    string Apellidos;
    string tipoVuelo;
};

struct Piloto
{
    string nombre;
    string apellidos;
    int experiencia;
    string tipoVuelo;
};

struct Avion
{
    string modelo;
    int aniosDeUso;
    string color;
};

struct DestinosHoras
{
    float horaPartida;
    float horaLlegada;
    string destinos;
};
namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.jLabelNombreDelPrograma = new System.Windows.Forms.Label();
            this.jLabelIndicaciones = new System.Windows.Forms.Label();
            this.txtGuardarNombreyApellido = new System.Windows.Forms.TextBox();
            this.jLabelDestino = new System.Windows.Forms.Label();
            this.cmbDestinos = new System.Windows.Forms.ComboBox();
            this.jLabelClaseVuelo = new System.Windows.Forms.Label();
            this.cmbClaseVuelo = new System.Windows.Forms.ComboBox();
            this.jLabelHorarios = new System.Windows.Forms.Label();
            this.cmbHorarios = new System.Windows.Forms.ComboBox();
            this.JButtomComprar = new System.Windows.Forms.Button();
            this.imprimirBoleto = new System.Windows.Forms.TextBox();
            this.jLabelNombreYApellido = new System.Windows.Forms.Label();
            this.jLabelValidacion1 = new System.Windows.Forms.Label();
            this.jLabelPilotos = new System.Windows.Forms.Label();
            this.jLabelAviones = new System.Windows.Forms.Label();
            this.cmbPilotos = new System.Windows.Forms.ComboBox();
            this.cmbAviones = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // jLabelNombreDelPrograma
            // 
            this.jLabelNombreDelPrograma.Font = new System.Drawing.Font("Palatino Linotype", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jLabelNombreDelPrograma.Location = new System.Drawing.Point(205, 9);
            this.jLabelNombreDelPrograma.Name = "jLabelNombreDelPrograma";
            this.jLabelNombreDelPrograma.Size = new System.Drawing.Size(252, 42);
            this.jLabelNombreDelPrograma.TabIndex = 0;
            this.jLabelNombreDelPrograma.Text = "$safeprojectname$";
            // 
            // jLabelIndicaciones
            // 
            this.jLabelIndicaciones.AutoSize = true;
            this.jLabelIndicaciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.jLabelIndicaciones.Location = new System.Drawing.Point(54, 51);
            this.jLabelIndicaciones.Name = "jLabelIndicaciones";
            this.jLabelIndicaciones.Size = new System.Drawing.Size(542, 17);
            this.jLabelIndicaciones.TabIndex = 1;
            this.jLabelIndicaciones.Text = "-Para comprar un boleto de avión rellene el formulario y presione el botón \"Compr" +
    "ar\"";
            this.jLabelIndicaciones.Click += new System.EventHandler(this.jLabelIndicaciones_Click);
            // 
            // txtGuardarNombreyApellido
            // 
            this.txtGuardarNombreyApellido.Location = new System.Drawing.Point(252, 79);
            this.txtGuardarNombreyApellido.Name = "txtGuardarNombreyApellido";
            this.txtGuardarNombreyApellido.Size = new System.Drawing.Size(377, 22);
            this.txtGuardarNombreyApellido.TabIndex = 3;
            this.txtGuardarNombreyApellido.TextChanged += new System.EventHandler(this.txtGuardarNombreyApellido_TextChanged);
            // 
            // jLabelDestino
            // 
            this.jLabelDestino.AutoSize = true;
            this.jLabelDestino.Location = new System.Drawing.Point(54, 173);
            this.jLabelDestino.Name = "jLabelDestino";
            this.jLabelDestino.Size = new System.Drawing.Size(150, 16);
            this.jLabelDestino.TabIndex = 4;
            this.jLabelDestino.Text = "País-Ciudad de destino:";
            this.jLabelDestino.Click += new System.EventHandler(this.label4_Click);
            // 
            // cmbDestinos
            // 
            this.cmbDestinos.FormattingEnabled = true;
            this.cmbDestinos.Items.AddRange(new object[] {
            "Argentina-Buenos Aires",
            "Brazil-Brasilia",
            "Chile-Santiago de Chile",
            "Ecuador-Guayaquil",
            "Ecuador-Cuenca"});
            this.cmbDestinos.Location = new System.Drawing.Point(55, 192);
            this.cmbDestinos.Name = "cmbDestinos";
            this.cmbDestinos.Size = new System.Drawing.Size(294, 24);
            this.cmbDestinos.TabIndex = 5;
            // 
            // jLabelClaseVuelo
            // 
            this.jLabelClaseVuelo.AutoSize = true;
            this.jLabelClaseVuelo.Location = new System.Drawing.Point(57, 136);
            this.jLabelClaseVuelo.Name = "jLabelClaseVuelo";
            this.jLabelClaseVuelo.Size = new System.Drawing.Size(97, 16);
            this.jLabelClaseVuelo.TabIndex = 6;
            this.jLabelClaseVuelo.Text = "Clase de vuelo";
            this.jLabelClaseVuelo.Click += new System.EventHandler(this.jLabelClaseVuelo_Click);
            // 
            // cmbClaseVuelo
            // 
            this.cmbClaseVuelo.FormattingEnabled = true;
            this.cmbClaseVuelo.Items.AddRange(new object[] {
            "Nacional",
            "Internacional"});
            this.cmbClaseVuelo.Location = new System.Drawing.Point(252, 128);
            this.cmbClaseVuelo.Name = "cmbClaseVuelo";
            this.cmbClaseVuelo.Size = new System.Drawing.Size(173, 24);
            this.cmbClaseVuelo.TabIndex = 7;
            this.cmbClaseVuelo.SelectedIndexChanged += new System.EventHandler(this.cmbClaseVuelo_SelectedIndexChanged);
            // 
            // jLabelHorarios
            // 
            this.jLabelHorarios.AutoSize = true;
            this.jLabelHorarios.Location = new System.Drawing.Point(397, 173);
            this.jLabelHorarios.Name = "jLabelHorarios";
            this.jLabelHorarios.Size = new System.Drawing.Size(134, 16);
            this.jLabelHorarios.TabIndex = 8;
            this.jLabelHorarios.Text = "Horarios Disponibles";
            this.jLabelHorarios.Click += new System.EventHandler(this.label6_Click);
            // 
            // cmbHorarios
            // 
            this.cmbHorarios.FormattingEnabled = true;
            this.cmbHorarios.Location = new System.Drawing.Point(400, 192);
            this.cmbHorarios.Name = "cmbHorarios";
            this.cmbHorarios.Size = new System.Drawing.Size(153, 24);
            this.cmbHorarios.TabIndex = 9;
            this.cmbHorarios.SelectedIndexChanged += new System.EventHandler(this.cmbHorarios_SelectedIndexChanged);
            // 
            // JButtomComprar
            // 
            this.JButtomComprar.Location = new System.Drawing.Point(294, 334);
            this.JButtomComprar.Name = "JButtomComprar";
            this.JButtomComprar.Size = new System.Drawing.Size(75, 35);
            this.JButtomComprar.TabIndex = 10;
            this.JButtomComprar.Text = "Comprar";
            this.JButtomComprar.UseVisualStyleBackColor = true;
            // 
            // imprimirBoleto
            // 
            this.imprimirBoleto.Location = new System.Drawing.Point(60, 375);
            this.imprimirBoleto.Name = "imprimirBoleto";
            this.imprimirBoleto.Size = new System.Drawing.Size(536, 22);
            this.imprimirBoleto.TabIndex = 11;
            this.imprimirBoleto.TextChanged += new System.EventHandler(this.imprimirBoleto_TextChanged);
            // 
            // jLabelNombreYApellido
            // 
            this.jLabelNombreYApellido.AutoSize = true;
            this.jLabelNombreYApellido.Location = new System.Drawing.Point(52, 82);
            this.jLabelNombreYApellido.Name = "jLabelNombreYApellido";
            this.jLabelNombreYApellido.Size = new System.Drawing.Size(122, 16);
            this.jLabelNombreYApellido.TabIndex = 2;
            this.jLabelNombreYApellido.Text = "Nombre y Apellido:";
            this.jLabelNombreYApellido.Click += new System.EventHandler(this.label3_Click);
            // 
            // jLabelValidacion1
            // 
            this.jLabelValidacion1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.jLabelValidacion1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jLabelValidacion1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.jLabelValidacion1.Location = new System.Drawing.Point(52, 98);
            this.jLabelValidacion1.Name = "jLabelValidacion1";
            this.jLabelValidacion1.Size = new System.Drawing.Size(122, 18);
            this.jLabelValidacion1.TabIndex = 8;
            this.jLabelValidacion1.Text = "*Ingrese letras mayúsculas";
            this.jLabelValidacion1.Visible = false;
            this.jLabelValidacion1.Click += new System.EventHandler(this.label1_Click);
            // 
            // jLabelPilotos
            // 
            this.jLabelPilotos.AutoSize = true;
            this.jLabelPilotos.Location = new System.Drawing.Point(52, 231);
            this.jLabelPilotos.Name = "jLabelPilotos";
            this.jLabelPilotos.Size = new System.Drawing.Size(124, 16);
            this.jLabelPilotos.TabIndex = 12;
            this.jLabelPilotos.Text = "Pilotos disponibles:";
            this.jLabelPilotos.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // jLabelAviones
            // 
            this.jLabelAviones.AutoSize = true;
            this.jLabelAviones.Location = new System.Drawing.Point(397, 231);
            this.jLabelAviones.Name = "jLabelAviones";
            this.jLabelAviones.Size = new System.Drawing.Size(149, 16);
            this.jLabelAviones.TabIndex = 13;
            this.jLabelAviones.Text = "Aeronaves disponibles:";
            // 
            // cmbPilotos
            // 
            this.cmbPilotos.FormattingEnabled = true;
            this.cmbPilotos.Items.AddRange(new object[] {
            "Francisco Salcedo (15 años de experiencia)",
            "Sebastian Freire (15 años de experiencia)",
            "Paula Coronel (13 años de experiencia)",
            "Diego Bienavides (10 años de experiencia)",
            "Timothe Charlander (14 años de experiencia)",
            "Luisa Cordero (24 años de experiencia)",
            "Dominic Tebas (10 años  de experiencia)",
            "Julian Djokovic (6 años de experiencia)",
            "Francisco Ramirez  ( 10 años de experiencia)",
            "Leonor Marquez (8 años de experiencia)",
            "Stefan Lanvielle (19 años de experiencia)",
            "Lan Ying (13 años de experiencia)"});
            this.cmbPilotos.Location = new System.Drawing.Point(55, 263);
            this.cmbPilotos.Name = "cmbPilotos";
            this.cmbPilotos.Size = new System.Drawing.Size(294, 24);
            this.cmbPilotos.TabIndex = 14;
            // 
            // cmbAviones
            // 
            this.cmbAviones.FormattingEnabled = true;
            this.cmbAviones.Items.AddRange(new object[] {
            "Boeing 747-8",
            "Airbus A320",
            "Tupolev Tu-204",
            "Bombardier CRJ200",
            "ATR 42",
            "Ilyushin II-96",
            "Embraer ERJ 170",
            "Sukhoi SU100"});
            this.cmbAviones.Location = new System.Drawing.Point(400, 263);
            this.cmbAviones.Name = "cmbAviones";
            this.cmbAviones.Size = new System.Drawing.Size(153, 24);
            this.cmbAviones.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 577);
            this.Controls.Add(this.cmbAviones);
            this.Controls.Add(this.cmbPilotos);
            this.Controls.Add(this.jLabelAviones);
            this.Controls.Add(this.jLabelPilotos);
            this.Controls.Add(this.jLabelValidacion1);
            this.Controls.Add(this.imprimirBoleto);
            this.Controls.Add(this.JButtomComprar);
            this.Controls.Add(this.cmbHorarios);
            this.Controls.Add(this.jLabelHorarios);
            this.Controls.Add(this.cmbClaseVuelo);
            this.Controls.Add(this.jLabelClaseVuelo);
            this.Controls.Add(this.cmbDestinos);
            this.Controls.Add(this.jLabelDestino);
            this.Controls.Add(this.txtGuardarNombreyApellido);
            this.Controls.Add(this.jLabelNombreYApellido);
            this.Controls.Add(this.jLabelIndicaciones);
            this.Controls.Add(this.jLabelNombreDelPrograma);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label jLabelNombreDelPrograma;
        private System.Windows.Forms.Label jLabelIndicaciones;
        private System.Windows.Forms.TextBox txtGuardarNombreyApellido;
        private System.Windows.Forms.Label jLabelDestino;
        private System.Windows.Forms.ComboBox cmbDestinos;
        private System.Windows.Forms.Label jLabelClaseVuelo;
        private System.Windows.Forms.ComboBox cmbClaseVuelo;
        private System.Windows.Forms.Label jLabelHorarios;
        private System.Windows.Forms.ComboBox cmbHorarios;
        private System.Windows.Forms.Button JButtomComprar;
        private System.Windows.Forms.TextBox imprimirBoleto;
        private System.Windows.Forms.Label jLabelNombreYApellido;
        private System.Windows.Forms.Label jLabelValidacion1;
        private System.Windows.Forms.Label jLabelPilotos;
        private System.Windows.Forms.Label jLabelAviones;
        private System.Windows.Forms.ComboBox cmbPilotos;
        private System.Windows.Forms.ComboBox cmbAviones;
    }
}

